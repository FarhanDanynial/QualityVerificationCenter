<?= view($view, $data); ?>
